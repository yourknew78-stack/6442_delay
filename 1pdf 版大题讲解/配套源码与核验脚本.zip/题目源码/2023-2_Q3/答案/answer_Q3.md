# Question 3 — Reference answer
UID: <Your UID>
Name: <Your Name>

## Q3a — Multiple file formats
Define a DataReader interface whose read method produces a shared application model. Implement JsonReader, XmlReader, CsvReader and BespokeReader separately. Each implementation owns its parsing and format-specific validation, and converts the result into the common model. A reader factory selects a reader from an explicit format or registered extension. The application receives the DataReader abstraction and calls it without knowing the parsing library. This combines Strategy for interchangeable reading algorithms with a factory for construction. New formats can be added as implementations and registered without changing application processing. Readers can be unit-tested on small fixtures; application logic can be tested using an in-memory fake reader. Report malformed input with a consistent error contract rather than hiding it as valid empty data.

## Q3b — SOLID and the UML
The broad User abstraction violates Interface Segregation: clients and subclasses are forced to depend on capabilities they do not need. PhotoViewer needs photos, but depends on a User that also exposes accessResearch. Penguinologist is forced to implement getPhotos, and the supplied code returns null. A caller that expects a usable photo collection can therefore fail when a Penguinologist replaces another User; this is also a Liskov Substitution concern if that collection contract is promised by User. Basic users likewise should not be forced to provide research access.
Keep common account identity and login/logout in User. Extract PhotoProvider with getPhotos, and ResearchProvider with accessResearch. PhotoViewer depends only on PhotoProvider. Implement the photo capability on classes that actually support it, and the research capability on Penguinologist. If an account legitimately supports both capabilities, it can implement both interfaces. Align the BasicUser method name with the interface: the draft mixes viewPhotos and getPhotos. Do not treat returning null from an unsupported capability as a sound substitute for modelling the capability correctly.

## 中文讲解
策略模式：四种读法共用 read 入口，程序只需要“能读文件的人”，不必知道具体怎样解析 XML。工厂负责根据文件类型选出具体读法。
接口隔离：看图片的 PhotoViewer 只需要 getPhotos，不应该被迫依赖 accessResearch。原图把这些功能都塞进 User，导致 Penguinologist 的 getPhotos 只能返回 null。
代入例子：PhotoViewer 原本对 getPhotos() 的结果循环展示图片，换成 Penguinologist 后结果为 null，循环就出错。拆成 PhotoProvider 后，只有真正能提供图片的对象才能传入这个查看器。
