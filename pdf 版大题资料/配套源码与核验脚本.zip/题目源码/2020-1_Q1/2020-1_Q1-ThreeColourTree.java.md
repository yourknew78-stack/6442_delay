## ThreeColourTree.java 原题注释中文对照
本题将红黑树扩展为三色树数据结构。三色树具有以下性质：
- 性质 1：每个节点的颜色必须是 PINK、PURPLE 或 MAGENTA。
- 性质 2：根节点和每个叶子（NULL 指针）都是 PINK。
- 性质 3：从根到叶子的每条路径包含相同数量的 PINK 节点。
- 性质 4：MAGENTA 节点不能有 MAGENTA 子节点，而且至少有一个 PURPLE 子节点。
- 性质 5：PURPLE 节点的子节点只能是 PINK。

请实现 testProp1、testProp2、testProp3、testProp4，分别检查性质 1、2、3、4 是否成立。提示：testProp5() 已在代码中实现。可以定义额外方法，但不得改变给定方法的签名或类的包结构。请将 ThreeColourTree.java 上传到 Wattle 供评分。原注释作者：nanwang；类型参数：T。

各方法注释的含义如下：
- testProp1：实现该方法检查性质 1，可以定义辅助方法。
- testProp2：实现该方法检查性质 2，可以定义辅助方法。
- testProp3：实现该方法检查性质 3，可以定义辅助方法。
- testProp4：实现该方法检查性质 4，可以定义辅助方法。
- 空树构造函数：初始化空的 RBTree。
- 带 root 和 x 参数的添加方法：向以 root 为根的树插入新节点 x。root 类型为 Node<T>，表示插入位置所在树的根；x 为待插入的 Node<T>。
- 插入方法：将节点插入 RBTree，参数 x 为待插入的新节点。
- 演示用插入函数：安全地向树中插入一个值，参数 value（类型 T）为新节点的值。
- 带 x 和 v 参数的查找方法：若值存在于树中，返回对应节点。x 表示要查找的树根，v 表示查找目标，具体参数类型以源码声明为准。
- 按 key 查找的方法：若某节点的值等于 key，则返回该节点。参数 key（类型 T）为要查找的值。
- Node 类：已提供 childrenLeaves() 和 colorCount() 辅助方法，可以利用，也可以在 Node 中定义自己的辅助方法。原注释作者为 nanwang，泛型参数为 E。
