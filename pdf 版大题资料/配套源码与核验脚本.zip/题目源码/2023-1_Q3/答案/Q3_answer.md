# Question 3 — Reference answer
UID: <Your UID>
Name: <Your Name>

## Part 1 — Two SOLID principles
### Single Responsibility Principle
A class should have one reason to change. MDToken stores the semantic content of list elements, but its toString also decides their presentation, including four spaces per nesting level and a particular textual format. Changing the data model and changing output formatting therefore both modify this class. For example, an HTML renderer and a console renderer need different indentation and markup while representing the same list item.
### Open/Closed Principle
Software should allow extension without repeatedly modifying established code. MDToken represents ordered items, unordered items and a synthetic root using one type discriminator and constructors with different meaningful fields. Only ordered items use number. Adding task lists or headings to this representation would require new type values, additional fields or constructor variants, and changes in clients that branch on tokenType. For example, a checked task item requires a checked state which does not belong on every list token. The enum alone does not prove a violation; the concern is the resulting need to modify the central representation and its type-dependent consumers when adding new element kinds.

## Part 2 — Refactoring plan
Keep common immutable data, such as content and nesting level, in a small element abstraction. Model ordered and unordered items as concrete implementations; keep the sequence number only on ordered items. Represent the root separately so it does not pretend to have ordinary item content. Introduce a renderer abstraction and move indentation and presentation out of the data model. A parser or factory creates the correct concrete type, while tree traversal uses the common abstraction. Add a task-item implementation and a corresponding parser rule when extending the language; unchanged traversal code still works. A registry of parsing handlers can avoid a growing central switch. Define equality and hashCode consistently for the chosen semantic identity, handle null root content, and test rendering separately from parsing.

## 中文讲解
单一职责是“为什么会修改这个类”：现在既因字段变化修改，又因显示缩进变化修改。把显示工作移到 Renderer 后，换 HTML 样式不需要动存数据的类。
开闭原则是“增加类型时，尽量新增类，而不是到处改 if”。有序项才有 number，无序项不需要这个字段；将它们拆开，新增复选框列表时可以增加带 checked 字段的新类型。
具体例子：原 token 表示第 2 层的有序项 3. Apple；数据对象只保存 level=2、number=3、content=Apple。控制台渲染器负责加 8 个空格，HTML 渲染器负责生成标签，二者不改变 token 的内容。
注意 equals 当前不比较 level 和 number，这是原题的既定语义；不能未经讨论就把它当成必然错误。当前没有 hashCode 且根节点 content 可为 null，是额外可指出的实现问题。
