import parcel.Parcel;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.NoSuchElementException;

public class ParcelBST extends BinarySearchTree<Parcel> implements Iterable<Parcel>  {

    public ParcelBST(Parcel value, ParcelBST leftNode, ParcelBST rightNode) {
        super(value, leftNode, rightNode);
    }

    public ParcelBST(BinarySearchTree<Parcel> parcelBST) {
        super(parcelBST.value,parcelBST.leftNode,parcelBST.rightNode);
    }

    public ParcelBST(Tree<Parcel> parcelTree) {
        super(parcelTree.value,parcelTree.leftNode,parcelTree.rightNode);
    }

    public ParcelBST(Parcel value) {
        super(value);
    }


    @Override
    public Iterator<Parcel> iterator() {
        return new IteratorPreOrder();
    }

    class IteratorPreOrder implements Iterator<Parcel> {
        // Hint: value, left/right sub-trees can be accessed by:
        //    ParcelBST.this.value    ParcelBST.this.leftNode   ParcelBST.this.rightNode
        // Or equivalently directly:
        //    value   leftNode    rightNode


        // 栈记录尚未访问的非空子树。
        private java.util.Stack<Tree<Parcel>> stack = new java.util.Stack<Tree<Parcel>>();

        public IteratorPreOrder() {
            if (ParcelBST.this.value != null) stack.push(ParcelBST.this);
    }

        @Override
        public boolean hasNext() {
            return !stack.isEmpty();
    }
        @Override
        public Parcel next() {
            if (!hasNext()) throw new NoSuchElementException();
            Tree<Parcel> current = stack.pop();
            // 栈后进先出，先放右边才能先访问左边。
            if (current.rightNode != null && current.rightNode.value != null) stack.push(current.rightNode);
            if (current.leftNode != null && current.leftNode.value != null) stack.push(current.leftNode);
            return current.value;
    }
    }
}
