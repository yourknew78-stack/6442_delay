## XMLTable.java 原题注释中文对照
重要：该类尚未完成，请查找 TODO 注释。

Save() 方法已经提供。请实现 load() 读取 XML 文件，并实现 insert() 将新客户插入 XML 文件。

每个客户必须有 ID 值，但可以缺少以下列中的某些值：Name、Address、City、Postcode、Country。测试见 XMLTableTest.java。

方法注释分别表示：
- save：将所有记录保存到 XML 文件。
- load：从 XML 文件获取全部记录。
- insert：向 XML 文件插入新客户。
