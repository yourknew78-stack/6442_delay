public class Exponentiate implements Operation {

	private final int a;
	private final int b;

	public Exponentiate(int a, int b) {
		this.a = a;
		this.b = b;
	}

	public int getA() {
		return a;
	}

	public int getB() {
		return b;
	}

	public int calculate() {
        if (b < 0) throw new IllegalArgumentException("negative exponent");
        int result = 1;
        for (int i = 0; i < b; i++) result = Math.multiplyExact(result, a);
        return result;
    }
}
